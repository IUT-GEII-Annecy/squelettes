// Corriger le code suivant : 

#include <cs50.h>

int main(void)
{
    // Demande le nom et d'où la personne vient 
    nom = get_string("What is your name? ")
    lieu_de_vie = get_string("Where do you live? ")

    // Say hello
    print("Hello, %i, from %i!", nom, lieu_de_vie)
}
